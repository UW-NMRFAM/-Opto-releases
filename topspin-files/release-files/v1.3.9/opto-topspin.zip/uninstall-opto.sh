#!/bin/bash

TOPSPIN_DIR=$1
if [ -z "$TOPSPIN_DIR" ]
then
  echo No topspin directory given. Uninstall script quitting. You should invoke uninstall with something like this: "uninstall-opto.sh topspin3.6.5"
  exit 1
fi

# remove all files

sudo rm -v /opt/$TOPSPIN_DIR/classes/lib/opto-core.jar
sudo rm -v /opt/$TOPSPIN_DIR/classes/lib/opto-topspin.jar

sudo rm -v /opt/$TOPSPIN_DIR/classes/prop/flowbars/opto.prop

sudo rm -v /opt/$TOPSPIN_DIR/exp/stan/nmr/lists/pp/user/opto-realtime-hpdec

sudo rm -v /opt/$TOPSPIN_DIR/exp/stan/nmr/lists/vd/opto-shim.dat

sudo rm -v /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/close-opto.py
sudo rm -v /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/open-opto.py
sudo rm -v /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto-help.py
sudo rm -v /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto_listener.py
sudo rm -v /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto-settings.py
sudo rm -v /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/update.py
sudo rm -v /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto-status.py

sudo rm -v /opt/$TOPSPIN_DIR/opto/opto-help.pdf
sudo rm -v /opt/$TOPSPIN_DIR/opto/opto-settings.dat

sudo rm -v /opt/$TOPSPIN_DIR/prog/bin/scripts/close-opto.sh
sudo rm -v /opt/$TOPSPIN_DIR/prog/bin/scripts/open-opto.sh
sudo rm -v /opt/$TOPSPIN_DIR/prog/bin/scripts/opto.sh

# done

echo Uninstallation complete!

exit 0
