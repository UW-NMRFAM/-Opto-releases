import os
import socket
import datetime
import TopCmds
import struct
import re
import math
import sys

WORKSTATION = False   # set this on workstation options: True or False

HOST = "127.0.0.1"

env_val = os.getenv("OPTO_PORT")

if env_val is None or not env_val.isnumeric():
    
    # Note to Thiru: DO NOT CHANGE ME
    #   If you need opto to run on some other port set
    #   an environmental variable called OPTO_PORT in
    #   your shell to the number you want. The opto
    #   and macro code should just . Editing this
    #   constant is error prone and can end up with us
    #   committing code that doesn't work.
    
    PORT = 30811
    
else:
    
    PORT = int(env_val)


# create a socket object
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)


# bind the socket to the localhost and port
server_socket.bind((HOST, PORT))



# become a server socket
try:
    server_socket.listen(1)
except:
    XCMD('close-opto')
    server_socket.listen(1)



print("Listening on port {}...".format(PORT))

# flag to indicate if server should keep running

running = True



curdata = CURDATA()
# shape parameter intialization
beta_value = None
delta_value = None
shape_values_storage = {}
opt_shapes = None

# plot parameter intialization
intarray=[]
fidarray=[]
fidarray1=[]
line_width_array=[]
fidarray_2H=[]
line_width_array_2H=[]
fidarray_sum=[]
line_width_array.append(0)
#intarray.append(0)
fidarray1.append(0)
line_width_array_2H.append(0)
fidarray_2H.append(0)
fidarray_sum.append(0)
shape_values_storage = {
    i: {'beta': None, 'delta': None}
    for i in range(64)
}




nlevel= 0.0
nlevel1 = 0.0
nlevel_sum = 0.0

def format_message(msg):
    msg = msg.strip()
    
    # Match leading letters + first integer
    match = re.match(r'^([A-Za-z]+)(\d+)(.*)$', msg)
    if not match:
        return msg.upper()
    
    letters, first_num, rest = match.groups()
    
    # Uppercase letters
    parts = [letters.upper()]
    
    # First number forced as integer
    first_num_int = int(first_num)
    parts.append(str(first_num_int))
    
    # Look for next number (float or int) in the remaining string
    rest_match = re.findall(r'[-+]?\d*\.\d+|\d+', rest)  # float OR int
    parts.extend(rest_match)
    
    return " ".join(parts)

# loading the settings from the text file
full_dir = os.path.dirname(sys.argv[0])   # using the python directory handle
path_parts = full_dir.split(os.sep)
sys_path = os.sep.join(path_parts[:3])
opto_settings_file_path = os.path.join(sys_path, "opto","opto-settings.dat")

# getting the shim values
def shim_string():
    result_string = ""
    
    full_dir = os.path.dirname(sys.argv[0])   # using the python directory handle
    path_parts = full_dir.split(os.sep)
    sys_path = os.sep.join(path_parts[:6])
    shim_file_path = os.path.join(sys_path, "lists", "bsms", "optoshim")
    opto_shim_limits_file_path = os.path.join(sys_path, "lists", "vd", "opto-shim.dat")

    if os.path.exists(shim_file_path):
        try:
            os.remove(shim_file_path)
            if terminal_output == "Debug":
                print("Temporary optoshim file found:", shim_file_path)
                print("Removing the temporary optoshim file")

            start = time.time()
            while time.time() - start < 4:
                if not os.path.exists(shim_file_path):
                    break
                time.sleep(0.2)

            if terminal_output == "Debug":
                print("Temporary optoshim file removed:", shim_file_path)
        except Exception as e:
            print("Error occurred while trying to delete the file: " + str(e))
            sys.exit(1)

    if WORKSTATION:
        None
    else:    
        XCMD('WSH optoshim')   #workstation
        
    if terminal_output == "Debug":
        print("Writing the shim file ..........")


    start = time.time()
    while time.time() - start < 4:
        if os.path.exists(shim_file_path):
            break
        time.sleep(0.2)

    if terminal_output == "Debug":
        print("Writing is complete")
        print("opening the file {}".format(shim_file_path))

    with open(shim_file_path, 'r') as shim_file:
        for line in shim_file:
            if line.startswith('#'):
                continue  # Skip comments
            parts = re.split(r'\s+', line.strip(), maxsplit=1)
            if len(parts) < 2:  # Ensure there are at least two parts
                continue
            name = parts[0]
            value = parts[1]
            # Read shim limits file for each shim
            with open(opto_shim_limits_file_path, 'r') as limits_file:
                for limits_line in limits_file:
                    if limits_line.startswith('#'):  # Skip comments in the limits file
                        continue 
                    if limits_line.startswith(name + ','):  # Match shim name
                        _, lower_limit, upper_limit, step_size = limits_line.strip().split(',')
                        if result_string:
                            result_string += ' '
                        result_string += "{} {} {} {} {}".format(name, lower_limit, upper_limit, value, step_size)
                        break  # Exit the loop once the matching line is found

    if terminal_output == "Debug":
        print(result_string)
    return result_string

DEFAULTS = {
    "Shim Mode": "Normal",
    "Shim Method": "Main coil",
    "Scaling Factor": "1",
    "Multi Detection": "",
    "Plot Result": "Yes",
    "Plot Type": "Fid_area",
    "Save Raw FIDs": "No",
    "Experiment Number for Raw Data": "0",
    "Experiment Number for Lock Coil Shim": "0",
    "Experiment Number for Raw Lock Coil FIDs": "0",
    "Terminal Output": "None",
}
# ---- Simple cache ----
_settings_cache = {
    "path": None,
    "mtime_ns": None,
    "size": None,
    "settings": None,
}
def _assign_globals_from_settings(settings):
    # Keep your exact global names
    global shim_mode, shim_method, scaling_factor, multi_detection, plot_result
    global plot_type, save_raw_fids, exp_num_for_raw_data, exp_num_for_lock_coil_shim
    global exp_num_for_raw_lock_coil_fids, terminal_output

    shim_mode = settings.get("Shim Mode", DEFAULTS["Shim Mode"])
    shim_method = settings.get("Shim Method", DEFAULTS["Shim Method"])
    scaling_factor = settings.get("Scaling Factor", DEFAULTS["Scaling Factor"])
    multi_detection = settings.get("Multi Detection", DEFAULTS["Multi Detection"])
    plot_result = settings.get("Plot Result", DEFAULTS["Plot Result"])
    plot_type = settings.get("Plot Type", DEFAULTS["Plot Type"])
    save_raw_fids = settings.get("Save Raw FIDs", DEFAULTS["Save Raw FIDs"])
    exp_num_for_raw_data = settings.get("Experiment Number for Raw Data", DEFAULTS["Experiment Number for Raw Data"])
    exp_num_for_lock_coil_shim = settings.get("Experiment Number for Lock Coil Shim", DEFAULTS["Experiment Number for Lock Coil Shim"])
    exp_num_for_raw_lock_coil_fids = settings.get("Experiment Number for Raw Lock Coil FIDs", DEFAULTS["Experiment Number for Raw Lock Coil FIDs"])
    terminal_output = settings.get("Terminal Output", DEFAULTS["Terminal Output"])

    if terminal_output == "Debug":
        print("opto is running with the following settings")
        for k, default in DEFAULTS.items():
            print("{}: {}".format(k, settings.get(k, default)))

def read_settings_from_file(file_path):
    """
    Reads settings from a file (robust to blank lines and '#' comments) and returns a dict.
    """
    settings = {}
    try:
        with open(file_path, "r") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if ": " in line:
                    key, value = line.split(": ", 1)
                    settings[key] = value
    except IOError:
        print("File {} not found.".format(file_path))
    except Exception as e:
        print("An error occurred while reading {}: {}".format(file_path, e))
    return settings

def load_settings_if_changed(file_path, force=False, update_globals=True):
    """
    Checks if the settings file changed since the last read (by mtime and size).
    If changed or force=True, re-reads and updates cache (and globals if requested).
    Returns (settings_dict, changed_bool).
    """
    try:
        st = os.stat(file_path)
    except OSError:
        print("File {} not found.".format(file_path))
        return (_settings_cache["settings"], False)

    changed = (
        force
        or _settings_cache["path"] != file_path
        or _settings_cache["mtime_ns"] != st.st_mtime
        or _settings_cache["size"] != st.st_size
    )

    if changed:
        settings = read_settings_from_file(file_path)
        merged = dict(DEFAULTS)
        merged.update(settings)

        _settings_cache.update({
            "path": file_path,
            "mtime_ns": st.st_mtime,
            "size": st.st_size,
            "settings": merged,
        })

        if update_globals:
            _assign_globals_from_settings(merged)

        print("Settings reloaded from {}".format(file_path))
        return (merged, True)

    return (_settings_cache["settings"], False)

file_path = opto_settings_file_path  # Adjust the path to your settings file
# Read settings from file during startup
settings, changed = load_settings_if_changed(file_path)



def int_area():

    full_dir = os.path.dirname(sys.argv[0])   # directory of current script
    path_parts = full_dir.split(os.sep)
    sys_path = os.sep.join(path_parts[:6])

    int_path = os.path.join(sys_path,"lists", "intrng", "opto-intrng")

    if os.path.exists(int_path):
        with open(int_path, "r") as file:
            lines = file.readlines()[1:]  # skip header

            for line in lines:
                if line.startswith("#"):
                    continue

                fields = line.split()
                if len(fields) >= 2:
                    try:
                        low_field = float(fields[0])
                        high_field = float(fields[1])
                        return low_field, high_field
                    except ValueError:
                        print("Invalid field values: {} - {}".format(fields[0], fields[1]))
                        continue
    else:
        print("No opto-intrng file found. Using full spectra width for integration! "
              "Save the opto-intrng file to select the region for integration.")
        return -1000, 1000






def calculate_peak_width(y):
    peak_max = max(y)  # Find the maximum peak value
    max_peak_index = y.index(peak_max)  # Find the index of the peak maximum

    if terminal_output == "Debug":
        print("peakmax, peakindex:", peak_max,max_peak_index)

    def half_max(y, peak_max):
        # Function to find the index closest to the half-maximum value of the peak
        return min(range(len(y)), key=lambda i: abs(y[i] - (peak_max / 1.5)))

    left_idx = half_max(y[:max_peak_index + 1], peak_max)  # Find left half-max index
    right_idx = half_max(y[max_peak_index:], peak_max) + max_peak_index  # Adjust right half-max index

    peak_width = (right_idx - left_idx)*res*0.5  # Calculate peak width
    if terminal_output == "Debug":
        print("widith, r,l indx", peak_width, right_idx, left_idx)
    
    return peak_width


def fidarea_measure(fid_path):
    try:
        with open(fid_path, "rb") as fid:
            level = 0.0
            td = int(GETPAR("TD"))
            endian = int(GETPAR("1s, BYTORDA"))  # Read the value of BYTORDA from the fid file
            dtypa = int(GETPAR("1s, DTYPA"))  # Read the value of DTYPA from the fid file
#            print("endian {} dtypa {}".format(endian, dtypa))

            td = int(td)

            if dtypa == 2:
                nc = 0
                size = 8
                if endian == 0:
                    directive = "<d"
                else:  # endian == 1
                    directive = ">d"
            else:  # dtypa != 2
                nc = int(GETPAR("1s, NC"))
                size = 4
                if endian == 0:
                    directive = "<i"
                else:  # endian == 1
                    directive = ">i"
            
            fid_data = []
            for i in range(td):
                pnt = struct.unpack(directive, fid.read(size))[0]
                level += abs(pnt)
#                level += abs(pnt)*i
            
            nlevel = (level) / ((2 ** nc) * td)

    except FileNotFoundError:
        nlevel = -1234567890  # BDZ return some unlikely value

    return nlevel
    


#Handling shapes
# getting the beta and delta from the buffers or file names if it exists:
def get_beta(index):
    try:
        if shape_values_storage and index in shape_values_storage:
            val = shape_values_storage[index].get("beta")
            if val is not None:
                return float(val)
        return 0.0
    except NameError:
        return 0.0

def get_delta(index):
    try:
        if shape_values_storage and index in shape_values_storage:
            val = shape_values_storage[index].get("delta")
            if val is not None:
                return float(val)
        return 0.0
    except NameError:
        return 0.0

def shape_name_value(index, shape_parameter):
    """
    Try to read beta/delta from SPNAM <index> if it starts with 'tan-shape-opto'.
    If not present (or wrong format), fall back to shape_values_storage.
    If still unavailable, return 0.0.
    """
    sparam = (shape_parameter or "").strip().upper()
    try:
        raw_name = TopCmds.GETPAR2("SPNAM {}".format(index))
    except Exception as e:
        # On read error: fall back immediately
        return get_beta(index) if sparam == "BETA" else (get_delta(index) if sparam == "DELTA" else 0.0)

    if raw_name:
        text = raw_name.strip()
        if text.lower().startswith("tan-shape-opto"):
            if sparam == "BETA":
                m = re.search(r"beta_(-?\d+(?:\.\d+)?)", text, re.IGNORECASE)
                if m:
                    try:
                        return float(m.group(1))
                    except Exception:
                        pass  # fall through to fallback
            elif sparam == "DELTA":
                m = re.search(r"delta_(-?\d+(?:\.\d+)?)", text, re.IGNORECASE)
                if m:
                    try:
                        return float(m.group(1))
                    except Exception:
                        pass  # fall through to fallback
            else:
                return 0.0  # unknown parameter requested

    # Fallback to the index-backed storage
    if sparam == "BETA":
        return get_beta(index)
    if sparam == "DELTA":
        return get_delta(index)
    return 0.0
    
                
def shape_generate(index, beta_value, delta_value):               
     
    amplitudes = []  # normalized to 0...100
    phases = []  # in degrees

    scale = 1000.0
    steps = 512
    k = (steps - 1) / 2.0
    if beta_value == 0.:
        alpha = 0.  # No division by Zero
    else:
        alpha = (2.0 / (steps - 1)) * math.atan(delta_value / beta_value)

    absBeta = abs(beta_value)
    for i in range(steps):
        di = absBeta * math.tan(alpha * (float(k - i)))
        amplitudes.append(scale * (1000. - di) / 1000.)
        phases.append(0.0)

    shape = SAVE_SHAPE("tan-shape-opto-{}".format(index), "Excitation", amplitudes, phases)
    PUTPAR("SPNAM {}".format(index), "tan-shape-opto-{}".format(index))
    if terminal_output == "Debug":
        print("tan-shape-opto-{} created with beta: {} delta: {}".format(index, beta_value, delta_value))
        print("shape loaded to SPNAM {} : tan-shape-opto-{}".format(index, index))    
        



##### realtime starts here

if shim_mode == "Real-time":
    RE(curdata)
    pulse_prog = GETPAR("PULPROG")
    if pulse_prog.startswith("opto-realtime"):
        PUTPAR("NS", "100000")
        if CONFIRM("OPTO conformation", "Start the aqustion in for realtime shim mode")== 0:
            EXIT()
        XCMD('zg yes', NO_WAIT_TILL_DONE)
        XCMD("opto-status 20 Initializing OPTO for real-time run, please wait...")
        SLEEP(10)
        XCMD('tr')
        SLEEP(10)
        scan_number = int(TopCmds.GETPAR("1s, NS"))
        print("Aqusition started ...........")
        if terminal_output == "Debug":
            print("Scan number before the loop: {}".format(scan_number))
        
        
    else:
        MSG("set the opto-realtime pulse program")
        EXIT()

## realtime done


while running:

    # wait for a client connection
    client_socket, address = server_socket.accept()

    # receive data from client
    data = client_socket.recv(4096).decode()

    # process received data
    if data:

        message = data.strip()
        if terminal_output == "Debug":
            print("Received message: " + message)

        if message == "close":

            print("Closing server socket...")
            running = False

        elif message == "opto_all_done_notice":
        
            for index, values in shape_values_storage.items():
    # Check if both beta and delta values are present
                if values['beta'] is not None and values['delta'] is not None:
                    beta_value = float(values['beta'])
                    delta_value = float(values['delta'])
                    if terminal_output == "Debug":
                        print(index, beta_value,delta_value)
                    amplitudes = []  # normalized to 0...100
                    phases = []  # in degrees

                    scale = 1000.0
                    steps = 512
                    k = (steps - 1) / 2.0
                    if beta_value == 0.:
                        alpha = 0.  # No division by Zero
                    else:
                        alpha = (2.0 / (steps - 1)) * math.atan(delta_value / beta_value)

                    absBeta = abs(beta_value)
                    for i in range(steps):
                        di = absBeta * math.tan(alpha * (float(k - i)))
                        amplitudes.append(scale * (1000. - di) / 1000.)
                        phases.append(0.0)
                    shape = SAVE_SHAPE("tan-shape-opto-{}-beta_{}-delta_{}".format(index,beta_value, delta_value), "Excitation", amplitudes, phases)
#                    print("tan-shape-opto-{} created with beta: {} delta: {}".format(beta_index,beta_value, delta_value))
                    print("shape file is saved with file name:tan-shape-opto-{}-beta_{}-delta_{}".format(index,beta_value, delta_value))
                    PUTPAR("SPNAM {}".format(index), "tan-shape-opto-{}-beta_{}-delta_{}".format(index,beta_value, delta_value))
                    print("shape loaded to SPNAM {} : tan-shape-opto-{}-beta_{}-delta_{}".format(index, index,beta_value, delta_value))
                    beta_value = None
                    delta_value = None
                    opt_shapes = "yes"
       
            XCMD("STOP")
            if shim_mode == "Real-time":
                PUTPAR("NS", "32")
                
        
            if opt_shapes == "yes":
                MSG("<html>"
                    "<div align=\"center\"><b><font size=200 color=\"0047AB\">OPTO run complete.</font></b></div>"
                    "<font color=\"000000\">Shape optimization found, updated SPNAM files with optimized shapes.</font><br>"
                    "</html>")
                opt_shapes = None
                RE(curdata, show="y")
            else:
                
                MSG("<html>"
                    "<div align=\"center\"><b><font size=200 color=\"0047AB\">OPTO run complete.</font></b></div>"
                    "</html>")
                RE(curdata, show="y")    
                
    
            response = "ok"
    
            client_socket.sendall(response.encode())

        elif message == "opto_curexp_name":

            if curdata is None:
                response = "NO_EXP_NAME"
            else:
                response = str(curdata[0]+"-"+curdata[1])
    
            client_socket.sendall(response.encode())

        elif message == "opto_curexp_path":

            if curdata is None:
                response = "NO_EXP_PATH"
            else:
                response = str(curdata[3] + os.sep + curdata[0] + os.sep + curdata[1])
    
            client_socket.sendall(response.encode())

        elif message == "opto_fidarea_measure":

            if curdata is None:
                response = "0.0"
            else:
                RE(curdata, show="n")
                
                if shim_mode == "Real-time":
                
                    scan_number=int(TopCmds.GETPAR("1s, NS")) #debug only delete in final
                    if terminal_output == "Debug":
                        print("reading data before tr {}".format(scan_number)) #debug only delete in final
                    d1_gs=float(GETPAR("D 1"))
                    aq_gs=float(GETPAR("AQ"))
                    delay=d1_gs+aq_gs
                    SLEEP(delay)
                    XCMD("tr")
                    SLEEP(delay)
                    scan_number=int(TopCmds.GETPAR("1s, NS")) #debug only delete in final
                    base_path, experiment_path, dataset_path = curdata[3], curdata[0], curdata[1]
                    combined_path = os.path.join(base_path, experiment_path, dataset_path)
                    fid_path = os.path.join(combined_path, "fid")
                    nlevel = fidarea_measure(fid_path)
                    fidarray.append(nlevel)
                    if terminal_output == "Debug":
                    	
                        print("reading data after tr {}".format(scan_number)) #debug only delete in final
                else:
                    RE(curdata, show="n")
                    XCPR('zg yes')
                    base_path, experiment_path, dataset_path = curdata[3], curdata[0], curdata[1]
                    combined_path = os.path.join(base_path, experiment_path, dataset_path)
                    fid_path = os.path.join(combined_path, "fid")
                    nlevel = fidarea_measure(fid_path)
                    fidarray.append(nlevel)
                    
                    if save_raw_fids== "Yes":
                        if plot_type == "Line_width":
                            index_for_ser = (len(line_width_array)+1)
                        else:
                            index_for_ser = (len(fidarray))
                   
                        ser_path=[curdata[0],str(exp_num_for_raw_data),curdata[2],curdata[3]]
                        if terminal_output == "Debug":
                            print(ser_path, index_for_ser)
                        CLOSEWIN()
                        RE(curdata,show="y")
                        
                        XCMD("wser {} {}".format(index_for_ser,exp_num_for_raw_data), WAIT_TILL_DONE)
                        if terminal_output == "Debug":
                            print("saved the Raw FID to experiemnt number {}".format(index_for_ser))


# plotting funtion, selection of FID or line width based on the settings file, Defualt is FID_area
        
                if plot_result == "Yes":
                    if plot_type == "Line_width":
                        XCPR('efp')
                        XCPR('abs n')
                        lf, hf = int_area()
                        y = GETPROCDATA(lf, hf)  # Get the process data
                        res = float(GETPAR('HZpPT'))  # Get a parameter, presumably the resolution                              
                        line_width = calculate_peak_width(y)
                        line_width_array.append(line_width)
                        if shim_method != "Main with Lock coil":
                            CLOSEWIN()
                            DISPLAY_DATALIST([line_width_array], None, "OPTO_Line_Width", 0)
                    else: # plot_type is not Line Width
                        if shim_method != "Main with Lock coil":
                            if len(fidarray)>2 :
                                CLOSEWIN()
                                DISPLAY_DATALIST([fidarray], None, "OPTO_FID_area", 0)
                                
#Done with plotting###############################################################################################


#####Lock channel                        
                if shim_method == "Main with Lock coil":
                    path2 = os.path.join(base_path, experiment_path, exp_num_for_lock_coil_shim)
                    H2_exp_path = os.path.join(base_path, experiment_path,exp_num_for_lock_coil_shim,"pdata","1")
                    if terminal_output == "Debug":
                        print("H2_exp_path {}".format(H2_exp_path))
                    fid_path2 = os.path.join(path2, "fid")
                    RE_PATH(H2_exp_path, show="n")
                    if multi_detection== "Dual":
                        print("Using dual receiver :{}".format(H2_exp_path))
                        nlevel1 = fidarea_measure(fid_path2)
                    else:
                        XCPR('zg yes')
                        nlevel1 = fidarea_measure(fid_path2)
                        
                    d_scaling=nlevel/(nlevel+nlevel1)
                    nlevel_sum=2*(((1-d_scaling)*nlevel)+(d_scaling*nlevel1))
                    print("scaling factor:{}".format(d_scaling))
                    
                    if save_raw_fids== "Yes":
                        CLOSEWIN()
                        RE_PATH(H2_exp_path, show="y")
                        XCMD("wser {} {}".format(index_for_ser,exp_num_for_raw_lock_coil_fids), WAIT_TILL_DONE)
                        if terminal_output == "Debug":
                            print("saved the Raw FID to experiemnt number {}".format(index_for_ser))
                    
# plotting funtion, selection of FID or line width based on the settings file, Defualt is FID_area
    
                    if plot_result == "Yes":
                        if plot_type == "Line_width":
                            XCPR('efp')
                            XCPR('abs n')
                            y = GETPROCDATA(-1000, 1000)  # Get the process data
                            res = float(GETPAR('HZpPT'))  # Get a parameter,  resolution
                            line_width = calculate_peak_width(y)
                            line_width_array_2H.append(line_width)
                            CLOSEWIN()
                            DISPLAY_DATALIST([line_width_array,line_width_array_2H], None, "OPTO Linewidth", 0)
       
                        else:  # fid area
                            fidarray1.append(nlevel)
                            fidarray_2H.append(nlevel1)
                            fidarray_sum.append(nlevel_sum)
                    
                                
                            CLOSEWIN()
                            if terminal_output == "Debug":
                                print("Main, {}, lock, {}, sum, {}".format(nlevel, nlevel1, nlevel_sum, scaling_factor))
                            try:
                                with open('{}{}fid_sum_lock.txt'.format(combined_path, os.sep), 'a') as file:
                                    file.write('Main, {}, lock, {}, sum, {} \n'.format(nlevel, nlevel1, nlevel_sum))
#                            print([fidarray1,fidarray_2H,fidarray_sum])
                            except FileNotFoundError:
                                print("file not found ")  # BDZ return some unlikely value

                            DISPLAY_DATALIST([fidarray_sum,fidarray_2H,fidarray1], None, "OPTO FID area of main coil and lock coil", 0)
                            
#Done with plotting###############################################################################################
                    
                    if nlevel1 == -1234567890:
                        nlevel = -1234567890
                    else:
                        nlevel=nlevel_sum
                
                response = str(nlevel)
                
                if terminal_output == "Debug":
                    print("Fidarea:{}".format(nlevel))
                nlevel= 0.0
                nlevel1 = 0.0
                nlevel_sum = 0.0
    
            client_socket.sendall(response.encode())

        elif message.startswith("opto_get_param_value"):
            
            param = message[len("opto_get_param_value"):].strip()
            f_param=format_message(param)
#            print(shape_values_storage)
            if terminal_output == "Debug":
                print("{} Name formated to {}".format(param,f_param))
                
            if f_param.startswith("BETA"):
                name, index = f_param.split()
                index=int(index)
                response = shape_name_value(index, "BETA")
                print("beta {} {}".format(index, response))               	
                
            elif f_param.startswith("DELTA"):
                name, index = f_param.split()
                index = int(index)
                response = shape_name_value(index, "DELTA")
                print("delta {} {}".format(index, response))

            else:
                response = GETPAR(f_param) 
                if response is None:
                    response = "0.0"
            response = str(response)
            client_socket.sendall(response.encode())
            
        elif message == "opto_get_platform_info":

            version_info = TOPSPIN_VERSION()

            full_version_string = version_info[0]

            match = re.search(r'(TopSpin) (\d+\.\d+\.\d+)', full_version_string)

            if match:

                software_name = match.group(1)

                version_number = match.group(2)

                response = "{} {}".format(software_name, version_number)

            else:

                response = "Version information not found"

            client_socket.sendall(response.encode())

        elif message == "opto_pslabel":

            response = GETPAR("PULPROG")
            if response is None:
                response = "NO_PULPROG"
            
            client_socket.sendall(response.encode())

        elif message.startswith("opto_run_command"):

            command = message[len("opto_run_command"):]
            parameters = [parameter.strip() for parameter in command.split(',')]
            for parameter in parameters: 
                result=XCMD(parameter)
                if parameter.startswith("re"):
                    curdata=CURDATA()
  
            response = "ok"
            
            client_socket.sendall(response.encode())

        elif message == "opto_run_experiment":

            RE(curdata, show="n")
           
            run = XCPR('zg yes')

            response = "ok"
            
            client_socket.sendall(response.encode())

        elif message.startswith("opto_set_param"):

            shape = ""
            
            command = message[len("opto_set_param"):]
            f_command=format_message(command)
            name,number,value = f_command.strip().split()
            if terminal_output == "Debug":
                print("{} Name formated to {}".format(command,f_command))
            
########### Checking for shape optimization parameters and generating the shapes ########

            
            if name == "BETA":
                index = int(number)
                shape_values_storage[index]['beta'] = float(value)
                if terminal_output == "Debug":
                    print("beta_Value:{},beta_Index:{}".format(shape_values_storage[index]['beta'],index))
                if shape_values_storage[index]['delta'] is None:
                    print("Beta {} received = {}, Delta not initialized - skipping shape generation.".format(index, shape_values_storage[index]['beta']))
                else:
                    shape_generate(index, shape_values_storage[index]['beta'], shape_values_storage[index]['delta'])
                
                response = "ok"

            
            if name == "DELTA":
                index = int(number)
                shape_values_storage[index]['delta'] = float(value)
                if terminal_output == "Debug":
                    print("delta_Value:{},delta_index: {}".format(shape_values_storage[index]['delta'], index))
                if shape_values_storage[index]['beta'] is None:
                    print("Delta {} received = {}, Beta not initialized - skipping shape generation.".format(index, shape_values_storage[index]['delta']))
                else:
                    shape_generate(index, shape_values_storage[index]['beta'], shape_values_storage[index]['delta'])
            
                response = "ok"


            if name != "BETA" and name != "DELTA" :
                vr =  name + ' ' + number
                RE(curdata, show="n")
                PUTPAR(vr,value)
                
                if terminal_output == "Debug":
                    print("parameter: {}, value:{}".format(vr, value))
            
                response = "ok"
            
            client_socket.sendall(response.encode())

        elif message.startswith("opto_set_shim"):

            command = message[len("opto_set_shim"):]
            name, value = command.strip().split()
            command = "setsh " + name + " " + value
            result = XCPR(command)  
            
            if result.getResult() == 0:
                response = "ok"
            else:
                response = "None"
            
            client_socket.sendall(response.encode())
       
        elif message == "opto_shim_info":

            if WORKSTATION:
                response = "Z -1000 1000 1 2"       #workstation
            else:    
                response = shim_string()
            client_socket.sendall(response.encode())


        elif message == "opto_integration_limits":
            lf, hf = int_area()
            response = str(lf)+" "+str(hf)
            client_socket.sendall(response.encode())
   
            
        elif message == "opto_spectral_measure":

            if curdata is None:
                
                response = "0.0"
            
            else:
                RE(curdata, show="n")
                settings, changed = load_settings_if_changed(file_path)
                if changed:
                    print("Settings updated at runtime. Terminal Output = {}".format(terminal_output))
                if WORKSTATION:
                    None
                else:
                    XCPR('zg yes')     #not workstation
                XCPR('efp')
                XCPR('abs n')
                low_field, high_field = int_area()
                datapoints = GETPROCDATA(low_field, high_field)
                ns = int(GETPAR("1s, NS"))
                nc_proc = int(GETPAR("1s, NC_proc"))
                si = int(GETPAR("SI"))
                if len(datapoints) <= 0:
                    print("Illegal region: {}-{} ppm".format(low_field, high_field))  # error spectrum out of range
                    exit()

                sum = 0.0
                for point in datapoints:  # sum up the data points
                    sum += point

                nsum = sum / (ns * si)  # this value needs to return to OPTO for the evaluation
                
                if terminal_output == "Debug":
                    print("lf: " + str(low_field) + " ppm, hf: " + str(high_field) + " ppm, area: " + str(sum) + " normalized to :" + str(nsum))
                if save_raw_fids== "Yes":
                    ser_path=[curdata[0],str(exp_num_for_raw_data),curdata[2],curdata[3]]
                    index_for_ser = (len(intarray)+1)
                    RE(curdata,show="y")
                    XCMD("wser {} {}".format(index_for_ser,exp_num_for_raw_data), WAIT_TILL_DONE)
                    if terminal_output == "Debug":
                        print("saved the Raw FID to experiemnt number {}".format(index_for_ser))
                
#plotting function, can be made it to be in settings
                
                intarray.append(nsum)
                
                if plot_result == "Yes":
                    if len(intarray)>2:
                        CLOSEWIN()
                        DISPLAY_DATALIST([intarray], None, "OPTO_Intergated_area", 0)
#plotting function, can be made it to be in settings

                response = str(nsum)

            client_socket.sendall(response.encode())

        else:  # message did not match any of the above subcases

            response = "Unknown command"
            
            client_socket.sendall(response.encode())

    client_socket.close()

server_socket.close()
