import os
import sys
from javax.swing import JFrame, JLabel, JRadioButton, JButton, JPanel, ButtonGroup, JOptionPane, JTextField
from java.awt import GridBagConstraints, GridBagLayout

class SettingsGUI(JFrame):
    def __init__(self):
        super(SettingsGUI, self).__init__("Settings")
        self.settings_dict = self.load_settings()
        self.initUI()

    def initUI(self):
        self.setSize(900, 400)
        self.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE)
        panel = JPanel(GridBagLayout())
        self.getContentPane().add(panel)
        gbc = GridBagConstraints()
        gbc.fill = GridBagConstraints.HORIZONTAL
        gbc.gridx = 0
        gbc.gridy = 0

        self.shim_mode, _ = self.create_radio_group(panel, "Shim Mode:", ["Normal", "Real-time"], gbc, default=self.settings_dict.get("Shim Mode", "Normal"))

        self.shim_method_buttons, (main_coil_button, main_with_lock_coil_button) = self.create_radio_group(panel, "Shim Method:", ["Main coil", "Main with Lock coil"], gbc, default=self.settings_dict.get("Shim Method", "Main coil"))
        main_with_lock_coil_button.addActionListener(self.updateVisibility)
        main_coil_button.addActionListener(self.updateVisibility)

        self.lock_coil_components = JPanel(GridBagLayout())
        gbc_lock_coil = GridBagConstraints()
        gbc_lock_coil.fill = GridBagConstraints.HORIZONTAL
        gbc_lock_coil.gridx = 0
        gbc_lock_coil.gridy = 0
        self.scaling_factor_text = JTextField(self.settings_dict.get("Scaling Factor", "1"), 10)
        self.create_label_field(self.lock_coil_components, "Scaling factor:", self.scaling_factor_text, gbc_lock_coil)
        self.exp_num_for_lock_coil_shim_text = JTextField(self.settings_dict.get("Experiment Number for Lock Coil Shim", "0"), 10)
        self.create_label_field(self.lock_coil_components, "Exp Num for Lock Coil Shim:", self.exp_num_for_lock_coil_shim_text, gbc_lock_coil)
        self.exp_num_for_raw_lock_coil_fids_text = JTextField(self.settings_dict.get("Experiment Number for Raw Lock Coil FIDs", "0"), 10)
        self.create_label_field(self.lock_coil_components, "Exp Num for Raw Lock Coil FIDs:", self.exp_num_for_raw_lock_coil_fids_text, gbc_lock_coil)
        panel.add(self.lock_coil_components, gbc)
        self.lock_coil_components.setVisible(False)

        gbc.gridy += 1
        self.multi_detection, _ = self.create_radio_group(panel, "Multi Detection:", ["Single", "Dual"], gbc, default=self.settings_dict.get("Multi Detection", "Single"))
        gbc.gridy += 1
        self.plot_result, _ = self.create_radio_group(panel, "Plot Result:", ["Yes", "No"], gbc, default=self.settings_dict.get("Plot Result", "Yes"))
        gbc.gridy += 1
        self.plot_type, _ = self.create_radio_group(panel, "Plot Type:", ["Fid_area", "Line_width"], gbc, default=self.settings_dict.get("Plot Type", "Fid_area"))

        self.save_raw_buttons, (save_raw_yes_button, save_raw_no_button) = self.create_radio_group(panel, "Save Raw FIDs:", ["Yes", "No"], gbc, default=self.settings_dict.get("Save Raw FIDs", "No"))
        save_raw_yes_button.addActionListener(self.updateVisibility)
        save_raw_no_button.addActionListener(self.updateVisibility)
        gbc.gridy += 1
        self.exp_num_for_raw_data_text = JTextField(self.settings_dict.get("Experiment Number for Raw Data", "0"), 5)
        self.create_label_field(panel, "Exp Num for Raw data:", self.exp_num_for_raw_data_text, gbc)

        gbc.gridy += 1
        self.terminal_output, _ = self.create_radio_group(panel, "Terminal Output:", ["None", "Warnings", "Debug"], gbc, default=self.settings_dict.get("Terminal Output", "None"))

        gbc.gridy += 2
        apply_button = JButton("Apply", actionPerformed=self.applySettings)
        panel.add(apply_button, gbc)

        self.updateVisibility(None)
        self.setVisible(True)

    def create_label_field(self, panel, label_text, text_field, gbc):
        label = JLabel(label_text)
        panel.add(label, gbc)
        gbc.gridx += 1
        panel.add(text_field, gbc)
        gbc.gridx = 0
        gbc.gridy += 1

    def create_radio_group(self, panel, label_text, options, gbc, default=None):
        label = JLabel(label_text)
        panel.add(label, gbc)
        gbc.gridx += 1
        button_group = ButtonGroup()
        radio_buttons = []
        for option in options:
            radio_button = JRadioButton(option)
            if option == default:
                radio_button.setSelected(True)
            button_group.add(radio_button)
            panel.add(radio_button, gbc)
            radio_buttons.append(radio_button)
            gbc.gridx += 1
        gbc.gridx = 0
        gbc.gridy += 1
        return button_group, radio_buttons

    def updateVisibility(self, event):
        shim_elements = self.shim_method_buttons.getElements()
        show_lock_coil_options = False
        while shim_elements.hasMoreElements():
            button = shim_elements.nextElement()
            if button.getText() == "Main with Lock coil" and button.isSelected():
                show_lock_coil_options = True
                break
        self.lock_coil_components.setVisible(show_lock_coil_options)

        save_raw_elements = self.save_raw_buttons.getElements()
        show_raw_data_option = False
        while save_raw_elements.hasMoreElements():
            button = save_raw_elements.nextElement()
            if button.getText() == "Yes" and button.isSelected():
                show_raw_data_option = True
                break
        self.exp_num_for_raw_data_text.setVisible(show_raw_data_option)

    def applySettings(self, event):
        settings = {
            "Shim Mode": self.get_selected_radio_text(self.shim_mode),
            "Shim Method": self.get_selected_radio_text(self.shim_method_buttons),
            "Scaling Factor": self.scaling_factor_text.getText(),
            "Multi Detection": self.get_selected_radio_text(self.multi_detection),
            "Plot Result": self.get_selected_radio_text(self.plot_result),
            "Plot Type": self.get_selected_radio_text(self.plot_type),
            "Save Raw FIDs": self.get_selected_radio_text(self.save_raw_buttons),
            "Experiment Number for Raw Data": self.exp_num_for_raw_data_text.getText(),
            "Experiment Number for Lock Coil Shim": self.exp_num_for_lock_coil_shim_text.getText(),
            "Experiment Number for Raw Lock Coil FIDs": self.exp_num_for_raw_lock_coil_fids_text.getText(),
            "Terminal Output": self.get_selected_radio_text(self.terminal_output)
        }

        try:
            with open(opto_setting_path, 'w') as file:
                for k, v in settings.items():
                    file.write("{}: {}\n".format(k, v))
            JOptionPane.showMessageDialog(self, "Settings successfully saved to " + opto_setting_path)
        except Exception as e:
            JOptionPane.showMessageDialog(self, "Failed to save settings: " + str(e))

    def get_selected_radio_text(self, button_group):
        for radio_button in button_group.getElements():
            if radio_button.isSelected():
                return radio_button.getText()
        return "Not Selected"

    def load_settings(self):
        settings = {}
        if os.path.exists(opto_setting_path):
            try:
                with open(opto_setting_path, 'r') as file:
                    for line in file:
                        if ":" in line:
                            k, v = line.strip().split(":", 1)
                            settings[k.strip()] = v.strip()
            except:
                pass
        return settings

full_dir = os.path.dirname(sys.argv[0])
path_parts = full_dir.split(os.sep)
sys_path = os.sep.join(path_parts[:3])
opto_setting_path = os.path.join(sys_path, "opto", "opto-settings.dat")

if __name__ == "__main__":
    app = SettingsGUI()