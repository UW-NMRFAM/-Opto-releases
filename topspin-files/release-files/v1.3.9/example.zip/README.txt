These files are provided for demonstration purposes only. Please ensure that all power levels are set according to the limitations and specifications of your probe.

Installation Instructions

Copy the pulse program

Copy the pulse program hX into the default pulse program directory:

<TopSpin installation directory>/exp/stan/nmr/lists/pp/user

Copy the OPTO job file

Copy the file HC-CP-NMRFAM-demo.opto-job to your home directory:

/home/<username>/

Important Notes:
Load the pulse sequence in TopSpin.
Carefully adjust all parameters according to your probe specifications before acquisition.
Acquire the spectrum only after verifying all settings.
Running the OPTO Job
Launch OPTO as described in the manual.
Open the provided job file.


