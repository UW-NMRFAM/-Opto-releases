import TopCmds
import sys


def handle_H90():
    p46 = GETPAR("P 46")
    PUTPAR("P 14", p46)
    p14 = GETPAR("P 14")
    print("P14 is updated to {} from the value of P46: {}".format(p14, p46))
    
def handle_H180():
    p46_180 = float(GETPAR("P 46"))
    print(p46_180)
    p46 = str(p46_180/2)
    print(p46)
    PUTPAR("P 14", p46)
    PUTPAR("P 46", p46)    
    p14 = GETPAR("P 14")
    print("P14 is updated to {} p46 is updated to {} from the 180 value of P46: {}".format(p14, p46, p46_180))    

def handle_C90():
    p36 = GETPAR("P 36")
    PUTPAR("P 13", p36)
    p13 = GETPAR("P 13")
    print("P13 is updated to {} from the value of P36: {}".format(p13, p36))
    
def handle_C180():
    p36_180 = float(GETPAR("P 36"))
    p36=str(p36_180/2)
    PUTPAR("P 13", p36)
    p13 = GETPAR("P 13")
    print("P13 is updated to {} from the value of P36: {}".format(p13, p36_180))    

def handle_Cecho():
    p13 = float(GETPAR("P 13"))
    p36=str(p13*2)
    PUTPAR("P 36", p36)
    p13 = GETPAR("P 13")
    print("P36 is updated to {} from the value of P36: {}".format(p36, p13))           

def handle_N90():
    p56 = GETPAR("P 56")
    PUTPAR("P 15", p56)
    p15 = GETPAR("P 15")
    print("P15 is updated to {} from the value of P56: {}".format(p15, p56))
    
def handle_N180():
    p56_180 = float(GETPAR("P 56"))
    p56=str(p56_180/2)
    PUTPAR("P 15", p56)
    p15 = GETPAR("P 15")
    print("P15 is updated to {} from the value of P56: {}".format(p15, p56_180))
    
def handle_Cecho():
    p15 = float(GETPAR("P 15"))
    p56=str(p15*2)
    PUTPAR("P 56", p56)
    p13 = GETPAR("P 15")
    print("P36 is updated to {} from the value of P36: {}".format(p56, p15))      

        
        

def main():
    if len(sys.argv) > 1:
        if sys.argv[1] == "H90":
            handle_H90()
        elif sys.argv[1] == "C90":
            handle_C90()
        elif sys.argv[1] == "N90":
            handle_N90()
        elif sys.argv[1] == "H180":
            handle_H180()  
        elif sys.argv[1] == "C180":
            handle_C180()   
        elif sys.argv[1] == "N180":
            handle_N180()  
        elif sys.argv[1] == "C_echo":
            handle_Cecho() 
        elif sys.argv[1] == "N_echo":
            handle_Necho()                                                  
        else:
            print("Invalid argument")
    else:
        print("No argument provided")

if __name__ == "__main__":
    main()

