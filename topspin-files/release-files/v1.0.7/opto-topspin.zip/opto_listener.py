import os
import socket
import datetime
import TopCmds
import struct
import re
import math
import sys

HOST = "127.0.0.1"

env_val = os.getenv("OPTO_PORT")

if env_val is None or not env_val.isnumeric():
    
    # Note to Thiru: DO NOT CHANGE ME
    #   If you need opto to run on some other port set
    #   an environmental variable called OPTO_PORT in
    #   your shell to the number you want. The opto
    #   and macro code should just work. Editing this
    #   constant is error prone and can end up with us
    #   committing code that doesn't work.
    
    PORT = 30811
    
else:
    
    PORT = int(env_val)

# create a socket object
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# bind the socket to the localhost and port
server_socket.bind((HOST, PORT))

# become a server socket
server_socket.listen(2)

print("Listening on port {}...".format(PORT))

# flag to indicate if server should keep running

running = True

curdata = CURDATA()
# shape parameter intialization
beta_value = None
delta_value = None
shape_values_storage = {}

# plot parameter intialization
intarray=[]
fidarray=[]
fidarray1=[]
line_width_array=[]
fidarray_2H=[]
line_width_array_2H=[]
fidarray_sum=[]
line_width_array.append(0)
#intarray.append(0)
fidarray1.append(0)
line_width_array_2H.append(0)
fidarray_2H.append(0)
fidarray_sum.append(0)

nlevel= 0.0
nlevel1 = 0.0
nlevel_sum = 0.0

# loading the settings from the text file
full_dir = os.path.dirname(sys.argv[0])   # using the python directory handle
path_parts = full_dir.split(os.sep)
sys_path = os.sep.join(path_parts[:3])
opto_settings_file_path = os.path.join(sys_path, "opto","opto-settings.dat")

def read_settings_from_file(file_path):
    """
    Reads settings from a file and returns a dictionary of those settings.
    """
    settings = {}
    try:
        with open(file_path, 'r') as file:
            for line in file:
                key, value = line.strip().split(': ', 1)
                settings[key] = value
    except FileNotFoundError:
        print("File {} not found.".format(file_path))
    except Exception as e:
        print("An error occurred: {}".format(e))
    
    return settings

def calculate_peak_width(y):
    peak_max = max(y)  # Find the maximum peak value
    max_peak_index = y.index(peak_max)  # Find the index of the peak maximum

    print("peakmax, peakindex:", peak_max,max_peak_index)

    def half_max(y, peak_max):
        # Function to find the index closest to the half-maximum value of the peak
        return min(range(len(y)), key=lambda i: abs(y[i] - (peak_max / 1.5)))

    left_idx = half_max(y[:max_peak_index + 1], peak_max)  # Find left half-max index
    right_idx = half_max(y[max_peak_index:], peak_max) + max_peak_index  # Adjust right half-max index

    peak_width = (right_idx - left_idx)*res*0.5  # Calculate peak width
    print("widith, r,l indx", peak_width, right_idx, left_idx)
    
    return peak_width


def fidarea_measure(fid_path):
    try:
        with open(fid_path, "rb") as fid:
            level = 0.0
            td = int(GETPAR("TD"))
            endian = int(GETPAR("1s, BYTORDA"))  # Read the value of BYTORDA from the fid file
            dtypa = int(GETPAR("1s, DTYPA"))  # Read the value of DTYPA from the fid file
            print("endian {} dtypa {}".format(endian, dtypa))

            td = int(td)

            if dtypa == 2:
                nc = 0
                size = 8
                if endian == 0:
                    directive = "<d"
                else:  # endian == 1
                    directive = ">d"
            else:  # dtypa != 2
                nc = int(GETPAR("1s, NC"))
                size = 4
                if endian == 0:
                    directive = "<i"
                else:  # endian == 1
                    directive = ">i"
            
            fid_data = []
            for i in range(td):
                pnt = struct.unpack(directive, fid.read(size))[0]
                level += abs(pnt)
#                level += abs(pnt)*i
            
            nlevel = (level) / ((2 ** nc) * td)

    except FileNotFoundError:
        nlevel = -1234567890  # BDZ return some unlikely value

    return nlevel
    
file_path = opto_settings_file_path  # Adjust the path to your settings file

# Read settings from file
settings = read_settings_from_file(file_path)

# Assign each setting to a variable
shim_mode = settings.get("Shim Mode", "Normal")  # Default values are provided if the key is not found
shim_method = settings.get("Shim Method", "Main coil")
scaling_factor = settings.get("Scaling Factor", "1")
multi_detection = settings.get("Multi Detection", "")
plot_result = settings.get("Plot Result", "Yes")
plot_type = settings.get("Plot Type", "Fid_area")
save_raw_fids = settings.get("Save Raw FIDs", "No")
exp_num_for_raw_data = settings.get("Experiment Number for Raw Data", "0")
exp_num_for_lock_coil_shim = settings.get("Experiment Number for Lock Coil Shim", "0")
exp_num_for_raw_lock_coil_fids = settings.get("Experiment Number for Raw Lock Coil FIDs", "0")

print("opto is running with the following settings")
print("Shim Mode: {}".format(shim_mode))
print("Shim Method: {}".format(shim_method))
print("Scaling Factor: {}".format(scaling_factor))
print("Multi Detection: {}".format(multi_detection))
print("Plot Result: {}".format(plot_result))
print("Plot Type: {}".format(plot_type))
print("Save Raw FIDs: {}".format(save_raw_fids))
print("Experiment Number for Raw Data: {}".format(exp_num_for_raw_data))
print("Experiment Number for Lock Coil Shim: {}".format(exp_num_for_lock_coil_shim))
print("Experiment Number for Raw Lock Coil FIDs: {}".format(exp_num_for_raw_lock_coil_fids))

#peak width calculation

path = str(curdata[3] + "/" + curdata[0] + "/" + curdata[1])
int_path = str(path + "/pdata/1/intrng")
if os.path.exists(int_path):
    with open(int_path, "r") as file:
        lines = file.readlines()
        lines = lines[1:]

        for line in lines:
            if line.startswith("#"):
                continue

            fields = line.split()
            if len(fields) >= 2:
                try:
                    low_field = float(fields[0])
                    high_field = float(fields[1])
                    break
                except ValueError:
                    print("Invalid field values: {} - {}".format(fields[0], fields[1]))
                print("lf: " + str(low_field) + " hf: " + str(high_field))
else:
    low_field = -1000
    high_field = 1000
    print("No intrng file found!!!!! using the full spectra width for integration!!!!!! save the intrng file to select the region for intergration")

##### realtime starts here

if shim_mode == "Real-time":
    RE(curdata)
    pulse_prog = GETPAR("PULPROG")
    if pulse_prog.startswith("opto-realtime"):
        PUTPAR("NS", "100000")
        if CONFIRM("OPTO conformation", "Start the aqustion in for realtime shim mode")== 0:
            EXIT()
        XCMD('zg yes', NO_WAIT_TILL_DONE)
        XCMD("opto-status 25 Initializing OPTO for real-time run, please wait...")
        SLEEP(15)
        XCMD('tr')
        SLEEP(10)
        scan_number = int(TopCmds.GETPAR("1s, NS"))
        print("Aqusition started ...........")
        print("Scan number before the loop: {}".format(scan_number))
        
        
    else:
        MSG("set the opto-realtime pulse program")
        EXIT()

## realtime done


while running:

    # wait for a client connection
    client_socket, address = server_socket.accept()

    # receive data from client
    data = client_socket.recv(4096).decode()

    # process received data
    if data:

        message = data.strip()
        print("Received message: " + message)

        if message == "close":

            print("Closing server socket...")
            running = False

        elif message == "opto_all_done_notice":
        
            for index, values in shape_values_storage.items():
    # Check if both beta and delta values are present
                if values['beta'] is not None and values['delta'] is not None:
                    beta_value = float(values['beta'])
                    delta_value = float(values['delta'])
                    print(index, beta_value,delta_value)
                    amplitudes = []  # normalized to 0...100
                    phases = []  # in degrees

                    scale = 1000.0
                    steps = 512
                    k = (steps - 1) / 2.0
                    if beta_value == 0.:
                        alpha = 0.  # No division by Zero
                    else:
                        alpha = (2.0 / (steps - 1)) * math.atan(delta_value / beta_value)

                    absBeta = abs(beta_value)
                    for i in range(steps):
                        di = absBeta * math.tan(alpha * (float(k - i)))
                        amplitudes.append(scale * (1000. - di) / 1000.)
                        phases.append(0.0)
                    shape = SAVE_SHAPE("tan-shape-opto-{}-beta_{}-delta-{}".format(beta_index,beta_value, delta_value), "Excitation", amplitudes, phases)
                    print("tan-shape-opto-{} created with beta: {} delta: {}".format(beta_index,beta_value, delta_value))
                    print("shape file is saved with file name:tan-shape-opto-{}-beta_{}-delta_{}".format(index,beta_value, delta_value))
                    beta_value = None
                    delta_value = None
       
            XCMD("STOP")
        
            MSG("OPTO run complete")
    
            response = "ok"
    
            client_socket.sendall(response.encode())

        elif message == "opto_curexp_name":

            if curdata is None:
                response = "NO_EXP_NAME"
            else:
                response = str(curdata[0]+"-"+curdata[1])
    
            client_socket.sendall(response.encode())

        elif message == "opto_curexp_path":

            if curdata is None:
                response = "NO_EXP_PATH"
            else:
                response = str(curdata[3] + "/" + curdata[0] + "/" + curdata[1])
    
            client_socket.sendall(response.encode())

        elif message == "opto_fidarea_measure":

            if curdata is None:
                response = "0.0"
            else:
                RE(curdata, show="n")
                
                if shim_mode == "Real-time":
                
                    scan_number=int(TopCmds.GETPAR("1s, NS")) #debug only delete in final
                    print("reading data before tr {}".format(scan_number)) #debug only delete in final
                    d1_gs=float(GETPAR("D 1"))
                    aq_gs=float(GETPAR("AQ"))
                    delay=d1_gs+aq_gs
                    SLEEP(delay)
                    XCMD("tr")
                    SLEEP(delay)
                    scan_number=int(TopCmds.GETPAR("1s, NS")) #debug only delete in final
                    base_path, experiment_path, dataset_path = curdata[3], curdata[0], curdata[1]
                    combined_path = os.path.join(base_path, experiment_path, dataset_path)
                    fid_path = os.path.join(combined_path, "fid")
                    nlevel = fidarea_measure(fid_path)
                    fidarray.append(nlevel)
                    print("reading data after tr {}".format(scan_number)) #debug only delete in final
                else:
                    RE(curdata, show="n")
                    XCPR('zg yes')
                    base_path, experiment_path, dataset_path = curdata[3], curdata[0], curdata[1]
                    combined_path = os.path.join(base_path, experiment_path, dataset_path)
                    fid_path = os.path.join(combined_path, "fid")
                    nlevel = fidarea_measure(fid_path)
                    fidarray.append(nlevel)
                    
                    if save_raw_fids== "Yes":
                        if plot_type == "Line_width":
                            index_for_ser = (len(line_width_array)+1)
                        else:
                            index_for_ser = (len(fidarray))
                   
                        ser_path=[curdata[0],str(exp_num_for_raw_data),curdata[2],curdata[3]]
                        print(ser_path, index_for_ser)
                        CLOSEWIN()
                        RE(curdata,show="y")
                        
                        XCMD("wser {} {}".format(index_for_ser,exp_num_for_raw_data), WAIT_TILL_DONE)
                        print("saved the Raw FID to experiemnt number {}".format(index_for_ser))
#                        RE(curdata, show="n")
                               
#                path = str(curdata[3] + "/" + curdata[0] + "/" + curdata[1])
#                fid_path = str(path + "/fid")


# plotting funtion, selection of FID or line width based on the settings file, Defualt is FID_area
        
                if plot_result == "Yes":
                    if plot_type == "Line_width":
                        XCPR('efp')
                        XCPR('abs n')
                        y = GETPROCDATA(low_field, high_field)  # Get the process data
                        res = float(GETPAR('HZpPT'))  # Get a parameter, presumably the resolution                              
                        line_width = calculate_peak_width(y)
                        line_width_array.append(line_width)
                        if shim_method != "Main with Lock coil":
                            CLOSEWIN()
                            DISPLAY_DATALIST([line_width_array], None, "OPTO_Line_Width", 0)
                        else:
                            fred=1
                    else:
                        
                        if shim_method != "Main with Lock coil":
                            if len(fidarray)>2 :
                                CLOSEWIN()
                                DISPLAY_DATALIST([fidarray], None, "OPTO_FID_area", 0)
                            else:
                                fred=2
                                
#Done with plotting###############################################################################################


#####Lock channel                        
                if shim_method == "Main with Lock coil":
                    path2 = os.path.join(base_path, experiment_path, exp_num_for_lock_coil_shim)
                    H2_exp_path = os.path.join(base_path, experiment_path,exp_num_for_lock_coil_shim,"pdata","1")
                    print("H2_exp_path {}".format(H2_exp_path))
                    fid_path2 = os.path.join(path2, "fid")
                    RE_PATH(H2_exp_path, show="n")
                    if multi_detection== "Dual":
                        print("Using dual receiver :{}".format(H2_exp_path))
                        nlevel1 = fidarea_measure(fid_path2)
                    else:
                        XCPR('zg yes')
                        nlevel1 = fidarea_measure(fid_path2)
                        
                    d_scaling=nlevel/(nlevel+nlevel1)
                    nlevel_sum=2*(((1-d_scaling)*nlevel)+(d_scaling*nlevel1))
                    print("scaling factor:{}".format(d_scaling))
                    
                    if save_raw_fids== "Yes":
                        CLOSEWIN()
                        RE_PATH(H2_exp_path, show="y")
                        XCMD("wser {} {}".format(index_for_ser,exp_num_for_raw_lock_coil_fids), WAIT_TILL_DONE)
                        print("saved the Raw FID to experiemnt number {}".format(index_for_ser))
                    
# plotting funtion, selection of FID or line width based on the settings file, Defualt is FID_area
    
                    if plot_result == "Yes":
                        if plot_type == "Line_width":
                            XCPR('efp')
                            XCPR('abs n')
                            y = GETPROCDATA(-1000, 1000)  # Get the process data
                            res = float(GETPAR('HZpPT'))  # Get a parameter,  resolution
                            line_width = calculate_peak_width(y)
                            line_width_array_2H.append(line_width)
                            CLOSEWIN()
                            DISPLAY_DATALIST([line_width_array,line_width_array_2H], None, "OPTO Linewidth", 0)
       
                        else:  # fid area
                            fidarray1.append(nlevel)
                            fidarray_2H.append(nlevel1)
                            fidarray_sum.append(nlevel_sum)
                    
                                
                            CLOSEWIN()
                            print("Main, {}, lock, {}, sum, {}".format(nlevel, nlevel1,nlevel_sum,scaling_factor ))
                            try:
                                with open('{}/fid_sum_lock.txt'.format(combined_path), 'a') as file:
                                    file.write('Main, {}, lock, {}, sum, {} \n'.format(nlevel, nlevel1,nlevel_sum))
#                            print([fidarray1,fidarray_2H,fidarray_sum])
                            except FileNotFoundError:
                                print("file not found ")  # BDZ return some unlikely value

                            DISPLAY_DATALIST([fidarray_sum,fidarray_2H,fidarray1], None, "OPTO FID area of main coil and lock coil", 0)
                            
#Done with plotting###############################################################################################
                    
                    if nlevel1 == -1234567890:
                        nlevel = -1234567890
                    else:
                        nlevel=nlevel_sum
                
                response = str(nlevel)
                
                print("Fidarea:{}".format(nlevel))
                nlevel= 0.0
                nlevel1 = 0.0
                nlevel_sum = 0.0
    
            client_socket.sendall(response.encode())

        elif message.startswith("opto_get_param_value"):
            
            param = message[len("opto_get_param_value"):].strip()
            
            response = GETPAR(param)
            if response is None:
                response = "0.0"
            
            client_socket.sendall(response.encode())
            
        elif message == "opto_get_platform_info":

            version_info = TOPSPIN_VERSION()

            full_version_string = version_info[0]

            match = re.search(r'(TopSpin) (\d+\.\d+\.\d+)', full_version_string)

            if match:

                software_name = match.group(1)

                version_number = match.group(2)

                response = "{} {}".format(software_name, version_number)

            else:

                response = "Version information not found"

            client_socket.sendall(response.encode())

        elif message == "opto_pslabel":

            response = GETPAR("PULPROG")
            if response is None:
                response = "NO_PULPROG"
            
            client_socket.sendall(response.encode())

        elif message.startswith("opto_run_command"):

            command = message[len("opto_run_command"):]
            parameters = [parameter.strip() for parameter in command.split(',')]
            print(len(parameters))
            
            for parameter in parameters:
                print(parameter)
                result=XCMD(parameter)
                print(result.getResult())
            
            response = "ok"
            
            client_socket.sendall(response.encode())

        elif message == "opto_run_experiment":

            RE(curdata, show="n")
           
            run = XCPR('zg yes')

            response = "ok"
            
            client_socket.sendall(response.encode())

        elif message.startswith("opto_set_param"):

            shape = ""
            
            command = message[len("opto_set_param"):]
            name,number,value = command.strip().split()
            
########### Checking for shape optimization parameters and generating the shapes ########

            if name == "BETA" or name == "DELTA":
                index = int(number)
                if index not in shape_values_storage:
                    # Initialize with None if not present
                    shape_values_storage[index] = {'beta': None, 'delta': None}
            
                if name == "BETA":
                    beta_value = float(value)
                    beta_index = int(number)
                    shape_values_storage[index]['beta'] = value
                    print("beta_Value:{},beta_Index:{}".format(beta_value, beta_index))
            
                    response = "ok"
            
                if name == "DELTA":
                    delta_value = float(value)
                    delta_index = int(number)
                    shape_values_storage[index]['delta'] = value
                    print("delta_Value:{},delta_index: {}".format(delta_value, delta_index))
            
                    response = "ok"

                if beta_value is not None and delta_value is not None:
                    if beta_index == delta_index:
                        amplitudes = []  # normalized to 0...100
                        phases = []  # in degrees

                        scale = 1000.0
                        steps = 512
                        k = (steps - 1) / 2.0
                        if beta_value == 0.:
                            alpha = 0.  # No division by Zero
                        else:
                            alpha = (2.0 / (steps - 1)) * math.atan(delta_value / beta_value)

                        absBeta = abs(beta_value)
                        for i in range(steps):
                            di = absBeta * math.tan(alpha * (float(k - i)))
                            amplitudes.append(scale * (1000. - di) / 1000.)
                            phases.append(0.0)

                        shape = SAVE_SHAPE("tan-shape-opto-{}".format(beta_index), "Excitation", amplitudes, phases)
                        print("tan-shape-opto-{} created with beta: {} delta: {}".format(beta_index,beta_value, delta_value))
                        beta_value = None
                        delta_value = None

########### Shape generation complete ###################################################

            else:  # name !="BETA" and name !="DELTA" :
                vr =  name + ' ' + number
                RE(curdata, show="n")
                PUTPAR(vr,value)
                print("parameter: {}, value:{}".format(vr, value))
            
                response = "ok"
            
            client_socket.sendall(response.encode())

        elif message.startswith("opto_set_shim"):

            command = message[len("opto_set_shim"):]
            name, value = command.strip().split()
            command = "setsh " + name + " " + value
            result = XCPR(command)  
            
            if result.getResult() == 0:
                response = "ok"
            else:
                response = "None"
            
            client_socket.sendall(response.encode())

        elif message == "opto_shim_info":

            shim_string = ""
            
            if curdata is not None:
                full_dir = os.path.dirname(sys.argv[0])   # using the python directory handle
                path_parts = full_dir.split(os.sep)
                sys_path = os.sep.join(path_parts[:6])
                shim_file_path = os.path.join(sys_path, "lists", "bsms", "optoshim")
                opto_shim_limits_file_path = os.path.join(sys_path, "lists", "vd", "opto-shim.dat")
                
                # NOTE if you are running on a data station comment out
                # this whole if clause and make sure the app has a dummy
                # optoshim file in the optoshim file path.
                
                if os.path.exists(shim_file_path):
                    try:
                        os.remove(shim_file_path)
                        print("Temporary optoshim file found:", shim_file_path)
                        print("Removing the temporary optoshim file")
                        XCMD("opto-status 8 Initializing OPTO run: Gathering parameters, please wait...")
                        SLEEP(4)
                        print("Temporary optoshim file removed:", shim_file_path)
                    except Exception as e:
                        print("Error occurred while trying to delete the file: " + str(e))
                        sys.exit(1)
             
                XCMD('WSH optoshim')
                print("Writing the shim file ..........")
              
                SLEEP(4)
                print("Writing is complete")
                file = open(shim_file_path, 'r')
                print("opening the file {}".format(shim_file_path))
               
                with open(shim_file_path, 'r') as shim_file:
                    for line in shim_file:
                        if line.startswith('#'):
                            continue  # Skip comments
                        parts = re.split(r'\s+', line.strip(), maxsplit=1)
                        if len(parts) < 2:  # Ensure there are at least two parts
                            continue
                        name = parts[0]
                        value = parts[1]
            # Read shim limits file for each shim
                        with open(opto_shim_limits_file_path, 'r') as limits_file:
                            for limits_line in limits_file:
                                if limits_line.startswith('#'):  # Skip comments in the limits file
                                    continue 
                                if limits_line.startswith(name + ','):  # Match shim name
                                    _, lower_limit, upper_limit, step_size = limits_line.strip().split(',')
                                    if shim_string:
                                        shim_string += ' '
                                    shim_string += "{} {} {} {} {}".format(name, lower_limit, upper_limit, value, step_size)
                                    break  # Exit the loop once the matching line is found

            print(shim_string)
            
            response = shim_string
            
            client_socket.sendall(response.encode())

        elif message == "opto_spectral_measure":

            if curdata is None:
                
                response = "0.0"
            
            else:
                RE(curdata, show="n")
                
                # NOTE if you are running on a data station comment out
                # the XCPR call and instead enable the SLEEP
                
                XCPR('zg yes')

#                   RE(curdata, show="n")


                XCPR('efp')
                XCPR('abs n')
                path = str(curdata[3] + "/" + curdata[0] + "/" + curdata[1])
                int_path = str(path + "/pdata/1/intrng")
                if os.path.exists(int_path):
                    with open(int_path, "r") as file:
                        lines = file.readlines()
                        lines = lines[1:]

                        for line in lines:
                            if line.startswith("#"):
                                continue

                            fields = line.split()
                            if len(fields) >= 2:
                                try:
                                    low_field = float(fields[0])
                                    high_field = float(fields[1])
                                    break
                                except ValueError:
                                    print("Invalid field values: {} - {}".format(fields[0], fields[1]))
                                    print("lf: " + str(low_field) + " hf: " + str(high_field))
                else:
                    low_field = -1000
                    high_field = 1000
                    print("No intrng file found!!!!! using the full spectra width for integration!!!!!! save the intrng file to select the region for integration")

                datapoints = GETPROCDATA(low_field, high_field)
                ns = int(GETPAR("1s, NS"))
                nc_proc = int(GETPAR("1s, NC_proc"))
                si = int(GETPAR("SI"))
                if len(datapoints) <= 0:
                    print("Illegal region: {}-{} ppm".format(low_field, high_field))  # error spectrum out of range
                    exit()

                sum = 0.0
                for point in datapoints:  # sum up the data points
                    sum += point

                nsum = sum / (ns * si)  # this value needs to return to OPTO for the evaluation
                print("lf: " + str(low_field) + " ppm, hf: " + str(high_field) + " ppm, area: " + str(sum) + " normalized to :" + str(nsum))
                if save_raw_fids== "Yes":
                    ser_path=[curdata[0],str(exp_num_for_raw_data),curdata[2],curdata[3]]
                    index_for_ser = (len(intarray)+1)
                    RE(curdata,show="y")
                    XCMD("wser {} {}".format(index_for_ser,exp_num_for_raw_data), WAIT_TILL_DONE)
                    print("saved the Raw FID to experiemnt number {}".format(index_for_ser))
                
#plotting function, can be made it to be in settings
                
                intarray.append(nsum)
                
                if len(intarray)>2:
                    CLOSEWIN()
                    DISPLAY_DATALIST([intarray], None, "OPTO_Intergated_area", 0)
#plotting function, can be made it to be in settings

                response = str(nsum)

            client_socket.sendall(response.encode())

        else:  # message did not match any of the above subcases

            response = "Unknown command"
            
            client_socket.sendall(response.encode())

    client_socket.close()

server_socket.close()
