import sys
from javax.swing import JFrame, JPanel, JProgressBar, JLabel, Timer
from java.awt import BorderLayout, Font
from java.awt.event import ActionListener

# Define a class to handle the ActionListener interface
class UpdateProgressListener(ActionListener):
    def __init__(self, progress_bar, frame, total_updates):
        self.progress_bar = progress_bar
        self.frame = frame
        self.update_count = 0
        self.total_updates = total_updates
        self.timer = None  # Initialize timer to None and set it later

    def set_timer(self, timer):
        self.timer = timer

    def actionPerformed(self, event):
        self.update_count += 1
        # Calculate progress as an integer percentage
        progress = int((self.update_count / float(self.total_updates)) * 100)
        self.progress_bar.setValue(progress)
        
        if self.update_count >= self.total_updates:
            # Close the frame when setup is complete
            self.frame.dispose()
            if self.timer:
                self.timer.stop()

# Function to set up and display the progress bar window with custom text and time
def setup_opto_progress(display_text, total_time):
    # Calculate the interval and total updates based on the desired total time
    update_interval = 100  # milliseconds between each progress update
    total_updates = int(total_time * 1000 / update_interval)

    # Create a frame (window)
    frame = JFrame("Setting up OPTO")
    frame.setSize(600, 100)
    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE)
    frame.setLocationRelativeTo(None)  # Center the window

    # Create a panel to hold the label and progress bar
    panel = JPanel()
    panel.setLayout(BorderLayout())

    # Create a label to display the custom setup message
    label = JLabel(display_text, JLabel.CENTER)
    label.setFont(Font("Arial", Font.PLAIN, 16))
    panel.add(label, BorderLayout.NORTH)

    # Create a progress bar
    progress_bar = JProgressBar(0, 100)
    progress_bar.setStringPainted(True)  # Display the progress percentage
    panel.add(progress_bar, BorderLayout.CENTER)

    # Add the panel to the frame
    frame.add(panel)
    frame.setVisible(True)

    # Create the listener and timer
    listener = UpdateProgressListener(progress_bar, frame, total_updates)
    timer = Timer(update_interval, listener)
    listener.set_timer(timer)  # Set the timer in the listener
    timer.start()

# Main execution to read command-line arguments

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: time.py <time> <text>")
    else:
        total_time = float(sys.argv[1])  # First argument is the time
        display_text = " ".join(sys.argv[2:])  # Join all remaining arguments for the text
        setup_opto_progress(display_text, total_time)
