import TopCmds
import os
import sys

try:

    full_dir = os.path.dirname(sys.argv[0])
    path_parts = full_dir.split(os.sep)
    sys_path = os.sep.join(path_parts[:3])  
    opto_help_path = os.path.join(sys_path, "opto", "opto-help.pdf")

    if os.path.exists(opto_help_path):
        os.system('xdg-open "{}"'.format(opto_help_path))
    else:
        TopCmds.MSG('The file does not exist: {}'.format(opto_help_path))
except Exception as e:
    TopCmds.MSG('An error occurred: {}'.format(str(e)))