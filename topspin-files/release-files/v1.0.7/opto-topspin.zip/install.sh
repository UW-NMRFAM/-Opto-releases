#!/bin/bash

TOPSPIN_DIR=$1
if [ -z "$TOPSPIN_DIR" ]
then
  echo No topspin directory given. Install script quitting. You should invoke install with something like this: "install.sh topspin3.6.5"
  exit 1
fi

# make opto.sh in the right place

OPTO_SH_NAME="/opt/$TOPSPIN_DIR/prog/bin/scripts/opto.sh"

LINE01="java -cp /opt/$TOPSPIN_DIR/classes/lib/opto-topspin.jar:/opt/$TOPSPIN_DIR/classes/lib/opto-core.jar nmrfam.opto.topspin.TopSpinMain \$@"

echo $LINE01 | sudo tee $OPTO_SH_NAME > /dev/null

# make open-opto.sh in the right place

OPEN_SH_NAME="/opt/$TOPSPIN_DIR/prog/bin/scripts/open-opto.sh"

LINE01="#!/bin/bash"
LINE02="command='/opt/$TOPSPIN_DIR/prog/bin/scripts/opto.sh'"
LINE03="\$command &"
LINE04="java_pid=\$(pgrep -f 'java.*opto-topspin.jar')"
LINE05='echo $java_pid  > "$HOME/opto-pid.txt"'
LINE06='echo "opto started with PID: $java_pid"'

echo "$LINE01" | sudo tee    $OPEN_SH_NAME > /dev/null
echo "$LINE02" | sudo tee -a $OPEN_SH_NAME > /dev/null
echo "$LINE03" | sudo tee -a $OPEN_SH_NAME > /dev/null
echo "$LINE04" | sudo tee -a $OPEN_SH_NAME > /dev/null
echo "$LINE05" | sudo tee -a $OPEN_SH_NAME > /dev/null
echo "$LINE06" | sudo tee -a $OPEN_SH_NAME > /dev/null

# make close-opto.sh in the right place

CLOSE_SH_NAME="/opt/$TOPSPIN_DIR/prog/bin/scripts/close-opto.sh"

#!/bin/bash
PORT=${OPTO_PORT:-30811}

LINE01="#!/bin/bash"
LINE02="PORT=\${OPTO_PORT:-30811}"
LINE03="exec 3<>/dev/tcp/127.0.0.1/\$PORT"
LINE04="if [ \$? -ne 0 ]; then"
LINE05="  echo Failed to connect to the server."
LINE06="  exit 1"
LINE07="fi"
LINE08="echo 'close' >&3"
LINE09="exec 3>&-"
LINE10='kill $(cat "$HOME/opto-pid.txt")'

echo "$LINE01" | sudo tee    $CLOSE_SH_NAME > /dev/null
echo "$LINE02" | sudo tee -a $CLOSE_SH_NAME > /dev/null
echo "$LINE03" | sudo tee -a $CLOSE_SH_NAME > /dev/null
echo "$LINE04" | sudo tee -a $CLOSE_SH_NAME > /dev/null
echo "$LINE05" | sudo tee -a $CLOSE_SH_NAME > /dev/null
echo "$LINE06" | sudo tee -a $CLOSE_SH_NAME > /dev/null
echo "$LINE07" | sudo tee -a $CLOSE_SH_NAME > /dev/null
echo "$LINE08" | sudo tee -a $CLOSE_SH_NAME > /dev/null
echo "$LINE09" | sudo tee -a $CLOSE_SH_NAME > /dev/null
echo "$LINE10" | sudo tee -a $CLOSE_SH_NAME > /dev/null


# make open-opto.py in the right place

OPEN_OPTO_PY_NAME="/opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/open-opto.py"

LINE01="import subprocess"
LINE02="curdata=CURDATA()"
LINE03="if curdata is None:"
LINE04="  MSG('Open the experiment that you want to use OPTO for')"
LINE05="  EXIT()"
LINE06="else:"
LINE07="  XCMD('opto_listener.py', wait=NO_WAIT_TILL_DONE)"
LINE08="  SLEEP(2)"
LINE09="script='$OPEN_SH_NAME'"
LINE10="subprocess.call([script])"

echo "$LINE01" | sudo tee    $OPEN_OPTO_PY_NAME > /dev/null
echo "$LINE02" | sudo tee -a $OPEN_OPTO_PY_NAME > /dev/null
echo "$LINE03" | sudo tee -a $OPEN_OPTO_PY_NAME > /dev/null
echo "$LINE04" | sudo tee -a $OPEN_OPTO_PY_NAME > /dev/null
echo "$LINE05" | sudo tee -a $OPEN_OPTO_PY_NAME > /dev/null
echo "$LINE06" | sudo tee -a $OPEN_OPTO_PY_NAME > /dev/null
echo "$LINE07" | sudo tee -a $OPEN_OPTO_PY_NAME > /dev/null
echo "$LINE08" | sudo tee -a $OPEN_OPTO_PY_NAME > /dev/null
echo "$LINE09" | sudo tee -a $OPEN_OPTO_PY_NAME > /dev/null
echo "$LINE10" | sudo tee -a $OPEN_OPTO_PY_NAME > /dev/null

# make close-opto.py in the right place

CLOSE_OPTO_PY_NAME="/opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/close-opto.py"

LINE01="import subprocess"
LINE02="script='$CLOSE_SH_NAME'"
LINE03="subprocess.call([script])"

echo "$LINE01" | sudo tee    $CLOSE_OPTO_PY_NAME > /dev/null
echo "$LINE02" | sudo tee -a $CLOSE_OPTO_PY_NAME > /dev/null
echo "$LINE03" | sudo tee -a $CLOSE_OPTO_PY_NAME > /dev/null

# make sure opto directory exists with correct permissions

if [ ! -d "/opt/$TOPSPIN_DIR/opto" ]; then
  sudo mkdir /opt/$TOPSPIN_DIR/opto
fi

sudo chown root:nmrsu /opt/$TOPSPIN_DIR/opto

# copy all the rest of the file data

sudo cp -v opto-core.jar       /opt/$TOPSPIN_DIR/classes/lib/
sudo cp -v opto-topspin.jar    /opt/$TOPSPIN_DIR/classes/lib/

sudo cp -v opto.prop           /opt/$TOPSPIN_DIR/classes/prop/flowbars/

sudo cp -v opto-realtime-hpdec /opt/$TOPSPIN_DIR/exp/stan/nmr/lists/pp/user/

sudo cp -v opto-shim.dat       /opt/$TOPSPIN_DIR/exp/stan/nmr/lists/vd/

sudo cp -v opto-help.py        /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/
sudo cp -v opto_listener.py    /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/
sudo cp -v opto-settings.py    /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/
sudo cp -v update.py           /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/
sudo cp -v opto-status.py      /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/

sudo cp -v opto-help.pdf       /opt/$TOPSPIN_DIR/opto/
sudo cp -v opto-parameters.dat /opt/$TOPSPIN_DIR/opto/
sudo cp -v opto-settings.dat   /opt/$TOPSPIN_DIR/opto/

sudo cp -v uninstall-opto.sh   /opt/$TOPSPIN_DIR/prog/bin/scripts/

# make ownership of all files consistent

sudo chown root:nmrsu /opt/$TOPSPIN_DIR/classes/lib/opto-core.jar
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/classes/lib/opto-topspin.jar

sudo chown root:nmrsu /opt/$TOPSPIN_DIR/classes/prop/flowbars/opto.prop

sudo chown root:nmrsu /opt/$TOPSPIN_DIR/exp/stan/nmr/lists/pp/user/opto-realtime-hpdec

sudo chown root:nmrsu /opt/$TOPSPIN_DIR/exp/stan/nmr/lists/vd/opto-shim.dat

sudo chown root:nmrsu /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto-help.py

sudo chown root:nmrsu /opt/$TOPSPIN_DIR/opto/opto-help.pdf
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/opto/opto-parameters.dat
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/opto/opto-settings.dat


sudo chown root:nmrsu /opt/$TOPSPIN_DIR/prog/bin/scripts/close-opto.sh
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/prog/bin/scripts/open-opto.sh
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/prog/bin/scripts/opto.sh
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/prog/bin/scripts/uninstall-opto.sh

sudo chown root:nmrsu /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/close-opto.py
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/open-opto.py
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto_listener.py
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto-settings.py
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/update.py
sudo chown root:nmrsu /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto-status.py

# make permissions of all files consistent

sudo chmod 644 /opt/$TOPSPIN_DIR/classes/lib/opto-core.jar
sudo chmod 644 /opt/$TOPSPIN_DIR/classes/lib/opto-topspin.jar

sudo chmod 644 /opt/$TOPSPIN_DIR/classes/prop/flowbars/opto.prop

sudo chmod 775 /opt/$TOPSPIN_DIR/opto

sudo chmod 644 /opt/$TOPSPIN_DIR/opto/opto-help.pdf
sudo chmod 666 /opt/$TOPSPIN_DIR/opto/opto-parameters.dat
sudo chmod 666 /opt/$TOPSPIN_DIR/opto/opto-settings.dat

sudo chmod 644 /opt/$TOPSPIN_DIR/exp/stan/nmr/lists/pp/user/opto-realtime-hpdec

sudo chmod 666 /opt/$TOPSPIN_DIR/exp/stan/nmr/lists/vd/opto-shim.dat

sudo chmod 644 /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/close-opto.py
sudo chmod 644 /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/open-opto.py
sudo chmod 644 /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto-help.py
sudo chmod 644 /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto_listener.py
sudo chmod 644 /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto-settings.py
sudo chmod 644 /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/update.py
sudo chmod 644 /opt/$TOPSPIN_DIR/exp/stan/nmr/py/user/opto-status.py

sudo chmod 755 /opt/$TOPSPIN_DIR/prog/bin/scripts/close-opto.sh
sudo chmod 755 /opt/$TOPSPIN_DIR/prog/bin/scripts/open-opto.sh
sudo chmod 755 /opt/$TOPSPIN_DIR/prog/bin/scripts/opto.sh
sudo chmod 755 /opt/$TOPSPIN_DIR/prog/bin/scripts/uninstall-opto.sh

# done

echo Installation complete!

echo

echo This software should not be modified or shared without
echo permission from NMRFAM. This software is provided "as is"
echo with no warranties of any kind and with no liability
echo attached to the use of the software or to loss of use of
echo systems driven by the software.
echo
echo Copyright UW-Madison Board of Regents. All rights reserved.

exit 0

