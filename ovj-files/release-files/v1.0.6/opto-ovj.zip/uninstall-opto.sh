
sudo rm /vnmr/bin/opto.sh
sudo rm /vnmr/java/opto-core.jar
sudo rm /vnmr/java/opto-ovj.jar
sudo rm /vnmr/java/opto-parameters.dat
sudo rm /vnmr/maclib/opto_curexp_name
sudo rm /vnmr/maclib/opto_curexp_path
sudo rm /vnmr/maclib/opto_param_info
sudo rm /vnmr/maclib/opto_shim_info
sudo rm /vnmr/maclib/opto_run_command
sudo rm /vnmr/maclib/opto_fidarea_measure
sudo rm /vnmr/maclib/opto_spectral_measure
sudo rm /vnmr/maclib/opto_run_experiment
sudo rm /vnmr/maclib/opto_get_var_status
sudo rm /vnmr/maclib/opto_pslabel
sudo rm /vnmr/maclib/opto_save_shims
sudo rm /vnmr/maclib/opto_load_shims
sudo rm /vnmr/maclib/opto_save_params
sudo rm /vnmr/maclib/opto_load_params
sudo rm /vnmr/maclib/opto_debug_before_setting_params
sudo rm /vnmr/maclib/opto_reset_power
sudo rm /vnmr/maclib/opto_all_done_notice
sudo rm /vnmr/maclib/opto_get_internal_value
sudo rm /vnmr/maclib/opto_set_internal_value

# done

echo Uninstallation complete!

exit 0 
