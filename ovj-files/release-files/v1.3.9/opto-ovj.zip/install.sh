echo java -cp /vnmr/java/opto-ovj.jar:/vnmr/java/opto-core.jar nmrfam.opto.ovj.OvjMain '$@' | sudo tee /vnmr/bin/opto.sh > /dev/null

sudo cp opto-core.jar                    /vnmr/java/
sudo cp opto-ovj.jar                     /vnmr/java/
sudo cp opto_curexp_name                 /vnmr/maclib/
sudo cp opto_curexp_path                 /vnmr/maclib/
sudo cp opto_param_info                  /vnmr/maclib/
sudo cp opto_shim_info                   /vnmr/maclib/
sudo cp opto_run_command                 /vnmr/maclib/
sudo cp opto_fidarea_measure             /vnmr/maclib/
sudo cp opto_spectral_measure            /vnmr/maclib/
sudo cp opto_run_experiment              /vnmr/maclib/
sudo cp opto_get_var_status              /vnmr/maclib/
sudo cp opto_pslabel                     /vnmr/maclib/
sudo cp opto_save_shims                  /vnmr/maclib/
sudo cp opto_load_shims                  /vnmr/maclib/
sudo cp opto_save_params                 /vnmr/maclib/
sudo cp opto_load_params                 /vnmr/maclib/
sudo cp opto_debug_before_setting_params /vnmr/maclib/
sudo cp opto_reset_power                 /vnmr/maclib/
sudo cp opto_all_done_notice             /vnmr/maclib/
sudo cp opto_get_internal_value          /vnmr/maclib/
sudo cp opto_set_internal_value          /vnmr/maclib/
sudo cp opto_integration_limits          /vnmr/maclib/
sudo cp uninstall-opto.sh                /vnmr/bin/

sudo chown vnmr1:nmr /vnmr/bin/opto.sh
sudo chown vnmr1:nmr /vnmr/bin/uninstall-opto.sh
sudo chown vnmr1:nmr /vnmr/java/opto-core.jar
sudo chown vnmr1:nmr /vnmr/java/opto-ovj.jar
sudo chown vnmr1:nmr /vnmr/maclib/opto_curexp_name
sudo chown vnmr1:nmr /vnmr/maclib/opto_curexp_path
sudo chown vnmr1:nmr /vnmr/maclib/opto_param_info
sudo chown vnmr1:nmr /vnmr/maclib/opto_shim_info
sudo chown vnmr1:nmr /vnmr/maclib/opto_run_command
sudo chown vnmr1:nmr /vnmr/maclib/opto_fidarea_measure
sudo chown vnmr1:nmr /vnmr/maclib/opto_spectral_measure
sudo chown vnmr1:nmr /vnmr/maclib/opto_run_experiment
sudo chown vnmr1:nmr /vnmr/maclib/opto_get_var_status
sudo chown vnmr1:nmr /vnmr/maclib/opto_pslabel
sudo chown vnmr1:nmr /vnmr/maclib/opto_save_shims
sudo chown vnmr1:nmr /vnmr/maclib/opto_load_shims
sudo chown vnmr1:nmr /vnmr/maclib/opto_save_params
sudo chown vnmr1:nmr /vnmr/maclib/opto_load_params
sudo chown vnmr1:nmr /vnmr/maclib/opto_debug_before_setting_params
sudo chown vnmr1:nmr /vnmr/maclib/opto_reset_power
sudo chown vnmr1:nmr /vnmr/maclib/opto_all_done_notice
sudo chown vnmr1:nmr /vnmr/maclib/opto_get_internal_value
sudo chown vnmr1:nmr /vnmr/maclib/opto_set_internal_value
sudo chown vnmr1:nmr /vnmr/maclib/opto_integration_limits

sudo chmod 755 /vnmr/bin/opto.sh
sudo chmod 755 /vnmr/bin/uninstall-opto.sh
sudo chmod 644 /vnmr/java/opto-core.jar
sudo chmod 644 /vnmr/java/opto-ovj.jar
sudo chmod 644 /vnmr/maclib/opto_curexp_name
sudo chmod 644 /vnmr/maclib/opto_curexp_path
sudo chmod 644 /vnmr/maclib/opto_param_info
sudo chmod 644 /vnmr/maclib/opto_shim_info
sudo chmod 644 /vnmr/maclib/opto_run_command
sudo chmod 644 /vnmr/maclib/opto_fidarea_measure
sudo chmod 644 /vnmr/maclib/opto_spectral_measure
sudo chmod 644 /vnmr/maclib/opto_run_experiment
sudo chmod 644 /vnmr/maclib/opto_get_var_status
sudo chmod 644 /vnmr/maclib/opto_pslabel
sudo chmod 644 /vnmr/maclib/opto_save_shims
sudo chmod 644 /vnmr/maclib/opto_load_shims
sudo chmod 644 /vnmr/maclib/opto_save_params
sudo chmod 644 /vnmr/maclib/opto_load_params
sudo chmod 644 /vnmr/maclib/opto_debug_before_setting_params
sudo chmod 644 /vnmr/maclib/opto_reset_power
sudo chmod 644 /vnmr/maclib/opto_all_done_notice
sudo chmod 644 /vnmr/maclib/opto_get_internal_value
sudo chmod 644 /vnmr/maclib/opto_set_internal_value
sudo chmod 644 /vnmr/maclib/opto_integration_limits

# done

echo Installation complete!

echo

echo If you have not already done so make sure to unzip the
echo opto-files.zip contents in the opto user\'s home directory
echo under a vnmrsys/opto subdirectory.

echo

echo This software should not be modified or shared without
echo permission from NMRFAM. This software is provided "as is"
echo with no warranties of any kind and with no liability
echo attached to the use of the software or to loss of use of
echo systems driven by the software.
echo
echo Copyright UW-Madison Board of Regents. All rights reserved.

exit 0 
